// challenge 1 - Rewrite this code so 
// that it doesn't repeat the same operation twice
var words = ["pea", "pod", "ram", "rod"];
words[0] = words[1];
words[1] = words[2];
words[2] = words[3];
words[3] = words[4];
console.log(words);

// challenge 2 - Create a function that prints 
// numbers from 1 to a given number (supplied from somewhere else)


// challenge 3 - Create a function that prints
// numbers from 1 to a given number but if the given number is 
// negative, print "Not Cool Dude, Give Me a Positive"
