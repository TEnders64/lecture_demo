// Oddities
// Build a function that takes in 3 arguments: 2 numbers and a string.
// If the sum of the numbers is odd, print the string.
// If the sum of the numbers is even, print "None Shall Pass"
// If the numbers are the same, print "Quite the Pair"
// If both numbers are negative, print "Somebody Needs a Pep Talk!"