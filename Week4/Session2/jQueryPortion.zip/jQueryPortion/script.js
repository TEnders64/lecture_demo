$(document).ready(function(){
    $('#hide').click(function(){
        $('#hide-content').hide();
    })
})